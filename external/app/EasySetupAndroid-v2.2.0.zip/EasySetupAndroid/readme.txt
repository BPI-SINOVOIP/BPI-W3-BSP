Integration notes on Android:

1. Copy com.broadcom.neeze.jar and libneeze.so to your project, with below directory structure:
    libs/
    |-- armeabi
    |   |-- libneeze.so
    |-- com.broadcom.neeze.jar

2. Add following permissions:
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.GET_TASKS" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE"/>

3. In java code:
    import com.broadcom.neeze.*;

    // set packet interval to 10ms. (default 8ms)
    //Neeze.SetPacketInterval(10);

    // send SSID and password
    Neeze.send("BroadcomAP", "12345678"); 

    // send with IP
    Neeze.send("BroadcomAP", "12345678", 0x0101a8c0); 

    // if you want to specify encryption key, use this:
    Neeze.send("BroadcomAP", "12345678", 0x0101a8c0, "Today is Friday?"); 

Note1: If you set encryption key, you must also set the same decryption key in target device.
Note2: Since above 2 calls block, note to put it in a standalone thread.
Note3: ip is in network order, so if you pass "192.168.1.1", it should be 0x0101a8c0

4. Class description:
public class Neeze {
    public static int send(String ssid, String password);

    public static int send(String ssid, String password, int ip);

    public static int send(String ssid, String password, int ip, int port);

    public static int send(String ssid, String password, int ip, String encryptionKey);

    public static int send(String ssid, String password, int ip, int port, String encryptionKey);

    public static int SetPacketInterval(int ms);
};

5. ES+AP
V2.0.0 adds SOFTAP concurrency for ES, to handle failure under some AP. In device side, add 0x80 protocol bit will start the softap, default named "es". In phone side, to send ssid/password through softap manner, make sure connect to device softap first (say "es"), then call API sendToAP()

public class Neeze {
    public static int sendToAp(String ssid, String password, int ip, int port, String encryptionKey);
};

A sample is provided in this demo.

6. Receve ssid list under softap mode
To get ssid list under softap, call:

public class Neeze {
	public static native byte[] listenForSsidList();
};

Upon success, a byte array is returned containing the ssid list. It's a sequence of rssi-security-length-ssid:

byte[0]: rssi
byte[1]: security (0=none, 1=wep, 2=wpa/wpa2-psk, 3=wpa2-enterprise)
byte[2]: ssid length
byte[3...]: ssid bytes

Please refer to onPostExecute() in Demo4.java for how to parse this array.
