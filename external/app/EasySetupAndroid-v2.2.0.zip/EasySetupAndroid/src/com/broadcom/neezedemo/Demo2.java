package com.broadcom.neezedemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.ToggleButton;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;

import com.broadcom.neeze.*;

public class Demo2 
    extends Activity
{
    static final String TAG = "demo";

    static final int ES = 0;
    static final int AP = 1;

    /* AP_SSID must match device's ssid. You can configure it with target lib. */
    static final String DEVICE_SSID = "es";

    int mMode = ES;
    int mLocalIp;
    String mSsid = null;
    String mPassword = null;
    Thread mThread = null;
    boolean mDone = true;
    TextView mInfo = null;
    Button mSwitch = null;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);

        mInfo = (TextView) findViewById(R.id.switch_mode_prompt);
        mSwitch = (Button) findViewById(R.id.switch_mode);

        /* Set packet interval. Default 8ms in lib. Probably you don't need to set it */
        SharedPreferences sp = Settings.getPrefs(Demo2.this);
        String packetInterval = sp.getString("packet_interval", getString(R.string.default_packet_interval));
        int interval = Integer.parseInt(packetInterval);
        Neeze.SetPacketInterval(interval); /* default 8ms */
    }

    public void onStartSending(View v) {
        String ssid = getSsid();
        if (ssid == null) {
            return;
        }

        if (ssid.equals(DEVICE_SSID)) 
            mMode = AP;
        else
            mMode = ES;

        EditText et = (EditText) findViewById(R.id.ssid);
        mSsid = et.getText().toString();
        et = (EditText) findViewById(R.id.password);
        mPassword = et.getText().toString();
        mDone = false;

        if (mThread == null) {
            mThread = new Thread() {
                public void run() {
                    while (!mDone) {
                        if (mMode == ES) {
                            //Neeze.send(mSsid, mPassword, mLocalIp, 1729, "0123456789abcdef");
                            Neeze.send(mSsid, mPassword, mLocalIp, 1729);
                            //Neeze.send(mSsid, mPassword);
                        } else {
                            Log.d("neeze", "send to ap");
                            Neeze.sendToAp(mSsid, mPassword, mLocalIp, 1729, "");
                            //Neeze.sendToAp(mSsid, mPassword, 0, 0, "");
                        }
                    }
                }
            };
        }

        mThread.start();

        LinearLayout ll = (LinearLayout) findViewById(R.id.sending);
        ll.setVisibility(View.VISIBLE);
        if (mMode == ES) {
            mInfo.setText(R.string.switch_mode_prompt_in_es);
            mSwitch.setText(R.string.switch_to_ap);
        } else {
            mInfo.setText(R.string.switch_mode_prompt_in_ap);
            mSwitch.setText(R.string.switch_to_es);
        }

        ll = (LinearLayout) findViewById(R.id.fill_ssid);
        ll.setVisibility(View.GONE);
    }

    public void onStopSending(View v) {
        mDone = true;
        mThread = null;

        LinearLayout ll = (LinearLayout) findViewById(R.id.sending);
        ll.setVisibility(View.GONE);

        ll = (LinearLayout) findViewById(R.id.fill_ssid);
        ll.setVisibility(View.VISIBLE);
    }

    public void onSwitchMode(View v) {
        String ssid = getSsid();
        if (ssid == null) return;

        if (mMode == ES) {
            if (ssid.equals(DEVICE_SSID)) {
                mMode = AP;
                mInfo.setText(R.string.switch_mode_prompt_in_ap);
                mSwitch.setText(R.string.switch_to_es);
            } else {
                Toast.makeText(this, R.string.switch_mode_prompt_in_es, Toast.LENGTH_SHORT).show();
            }
        } else {
            if (!ssid.equals(DEVICE_SSID)) {
                mMode = ES;
                mInfo.setText(R.string.switch_mode_prompt_in_es);
                mSwitch.setText(R.string.switch_to_ap);
            } else {
                Toast.makeText(this, R.string.switch_mode_prompt_in_ap, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        updateWifiInfo();
    }

    String getSsid() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (networkInfo.isConnected()) {
            WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifiManager.getConnectionInfo();
            String ssid = info.getSSID();
            if (ssid.startsWith("\"")) {
                ssid = ssid.substring(1, ssid.length()-1);
            }

            return ssid;
        }

        return null;
    }

    void updateWifiInfo() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        Log.d(TAG, "connected: "+networkInfo.isConnected());
        if (!networkInfo.isConnected()) {
            Log.d(TAG, getString(R.string.connect_wifi));

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.connect_wifi);
            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    finish();
                }
            });
            builder.show();

            return;
        }
        
        WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        mLocalIp = info.getIpAddress();
        Log.d(TAG, String.format("ip: 0x%x", mLocalIp));

        EditText et = (EditText) findViewById(R.id.ssid);
        String ssid = info.getSSID();
        if (ssid.startsWith("\"")) {
            ssid = ssid.substring(1, ssid.length()-1);
        }

        if (!ssid.equals(DEVICE_SSID)) {
            et.setText(ssid);
        }
    }

    void showErrorDialog() {
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
        case R.id.settings:
            Intent intent = new Intent();
            intent.setClass(this, Settings.class);
            startActivity(intent);
            return true;
        }

        return true;
    }
}
