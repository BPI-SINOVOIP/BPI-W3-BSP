package com.broadcom.neezedemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.wifi.*;
import android.net.wifi.WifiConfiguration.KeyMgmt;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.ToggleButton;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;

import java.util.List;

import com.broadcom.neeze.*;

public class Demo3 
    extends Activity
{
    static final String TAG = "demo";

    static final int ES = 0;
    static final int AP = 1;

    /* AP_SSID must match device's ssid. You can configure it with target lib. */
    static final String DEVICE_SSID = "es";

    int mMode = ES;
    int mLocalIp;
    String mSsid = null;
    String mPassword = null;
    Thread mThread = null;
    boolean mDone = true;
    TextView mInfo = null;
    Button mSwitch = null;

    IntentFilter mFilter = null;
    BroadcastReceiver mReceiver = null;
    boolean mScanRequested = false;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);

        mInfo = (TextView) findViewById(R.id.switch_mode_prompt);
        mSwitch = (Button) findViewById(R.id.switch_mode);

        /* Set packet interval. Default 8ms in lib. Probably you don't need to set it */
        SharedPreferences sp = Settings.getPrefs(Demo3.this);
        String packetInterval = sp.getString("packet_interval", getString(R.string.default_packet_interval));
        int interval = Integer.parseInt(packetInterval);
        Neeze.SetPacketInterval(interval); /* default 8ms */
    }

    @Override
    public void onResume() {
        super.onResume();

        updateWifiInfo();

        if (mFilter == null) {
            mFilter = new IntentFilter();
            mFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
            mFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
            mReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    handleWifiEvent(context, intent);
                }
            };
        }

        registerReceiver(mReceiver, mFilter);
    }

    @Override
    public void onPause() {
        super.onPause();

        unregisterReceiver(mReceiver);
    }

    void handleWifiEvent(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, action);
        if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
            ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            Log.d(TAG, "wifi network info, connected="+networkInfo.isConnected());

            NetworkInfo info = (NetworkInfo) intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
            Log.d(TAG, "intent network connected="+info.isConnected());
            if (info.isConnected()) {
                String ssid = getSsid();
                Log.d(TAG, "ssid="+ssid);
                if (ssid != null) {
                    if (ssid.equals(DEVICE_SSID)) {
                        mMode = AP;
                        mInfo.setText(R.string.switch_mode_prompt_in_ap);
                        mSwitch.setText(R.string.switch_to_es);
                    } else {
                        mMode = ES;
                        mInfo.setText(R.string.switch_mode_prompt_in_es);
                        mSwitch.setText(R.string.switch_to_ap);
                    }
                }
            }
        }

        if (action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
            if (mScanRequested) {
                WifiManager manager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);

                List<ScanResult> list = manager.getScanResults();
                boolean found = false;
                if (list != null) {
                    for (ScanResult result: list) {
                        if (result.SSID != null) {
                            Log.d(TAG, "ssid="+result.SSID);
                            if (DEVICE_SSID.equals(result.SSID)) {
                                found = true;
                                break;
                            }
                        }
                    }
                }

                if (found) {
                    mScanRequested = false;

                    WifiConfiguration conf = new WifiConfiguration();
                    conf.SSID = "\""+DEVICE_SSID+"\"";
                    conf.allowedKeyManagement.set(KeyMgmt.NONE);
                    int id = manager.addNetwork(conf);
                    if (id != -1) {
                        manager.enableNetwork(id, true);
                        mInfo.setText(String.format("Found SSID \"%s\", connecting...", DEVICE_SSID));
                        Log.d(TAG, "connect to "+DEVICE_SSID);
                    }
                } else {
                    Log.d(TAG, String.format("Scan for %s...", DEVICE_SSID));
                    manager.startScan();
                }
            }
        }
    }

    public void onStartSending(View v) {
        String ssid = getSsid();
        if (ssid == null) {
            return;
        }

        if (ssid.equals(DEVICE_SSID)) 
            mMode = AP;
        else
            mMode = ES;

        EditText et = (EditText) findViewById(R.id.ssid);
        mSsid = et.getText().toString();
        et = (EditText) findViewById(R.id.password);
        mPassword = et.getText().toString();
        mDone = false;

        if (mThread == null) {
            mThread = new Thread() {
                public void run() {
                    while (!mDone) {
                        if (mMode == ES) {
                            //Neeze.send(mSsid, mPassword, mLocalIp, 1729, "0123456789abcdef");
                            Neeze.send(mSsid, mPassword, mLocalIp, 1729);
                            //Neeze.send(mSsid, mPassword);
                        } else {
                            Neeze.sendToAp(mSsid, mPassword, mLocalIp, 1729, "");
                            //Neeze.sendToAp(mSsid, mPassword, 0, 0, "");
                        }
                    }
                }
            };
        }

        mThread.start();

        LinearLayout ll = (LinearLayout) findViewById(R.id.sending);
        ll.setVisibility(View.VISIBLE);
        if (mMode == ES) {
            mInfo.setText(R.string.switch_mode_prompt_in_es);
            mSwitch.setText(R.string.switch_to_ap);
        } else {
            mInfo.setText(R.string.switch_mode_prompt_in_ap);
            mSwitch.setText(R.string.switch_to_es);
        }

        ll = (LinearLayout) findViewById(R.id.fill_ssid);
        ll.setVisibility(View.GONE);
    }

    public void onStopSending(View v) {
        mDone = true;
        mThread = null;
        mScanRequested = false;

        LinearLayout ll = (LinearLayout) findViewById(R.id.sending);
        ll.setVisibility(View.GONE);

        ll = (LinearLayout) findViewById(R.id.fill_ssid);
        ll.setVisibility(View.VISIBLE);
    }

    public void onSwitchMode(View v) {
        String ssid = getSsid();
        if (ssid == null) return;

        if (mMode == ES) {
            if (ssid.equals(DEVICE_SSID)) {
                mMode = AP;
                mInfo.setText(R.string.switch_mode_prompt_in_ap);
                mSwitch.setText(R.string.switch_to_es);
            } else {
                WifiManager manager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
                manager.startScan();
                mScanRequested = true;
                mInfo.setText("Scanning...");
            }
        } else {
            if (!ssid.equals(DEVICE_SSID)) {
                mMode = ES;
                mInfo.setText(R.string.switch_mode_prompt_in_es);
                mSwitch.setText(R.string.switch_to_ap);
            } else {
                Toast.makeText(this, R.string.switch_mode_prompt_in_ap, Toast.LENGTH_SHORT).show();
            }
        }
    }

    String getSsid() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        Log.d(TAG, "getSsid, wifi connected="+networkInfo.isConnected());
        if (networkInfo.isConnected()) {
            WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifiManager.getConnectionInfo();
            String ssid = info.getSSID();
            Log.d(TAG, "getSsid, ssid="+ssid);
            if (ssid.startsWith("\"")) {
                ssid = ssid.substring(1, ssid.length()-1);
            }

            return ssid;
        }

        return null;
    }

    void updateWifiInfo() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        Log.d(TAG, "connected: "+networkInfo.isConnected());
        if (!networkInfo.isConnected()) {
            Log.d(TAG, getString(R.string.connect_wifi));

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.connect_wifi);
            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    finish();
                }
            });
            builder.show();

            return;
        }
        
        WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        mLocalIp = info.getIpAddress();
        Log.d(TAG, String.format("ip: 0x%x", mLocalIp));

        EditText et = (EditText) findViewById(R.id.ssid);
        String ssid = info.getSSID();
        if (ssid.startsWith("\"")) {
            ssid = ssid.substring(1, ssid.length()-1);
        }

        if (!ssid.equals(DEVICE_SSID)) {
            et.setText(ssid);
        }
    }

    void showErrorDialog() {
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
        case R.id.settings:
            Intent intent = new Intent();
            intent.setClass(this, Settings.class);
            startActivity(intent);
            return true;
        }

        return true;
    }
}
