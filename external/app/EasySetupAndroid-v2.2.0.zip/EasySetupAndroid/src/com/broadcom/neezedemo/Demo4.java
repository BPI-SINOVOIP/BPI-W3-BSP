package com.broadcom.neezedemo;

import android.app.Activity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.wifi.*;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;

import java.util.List;

import com.broadcom.neeze.*;

public class Demo4 
    extends Activity
    implements AdapterView.OnItemClickListener
{
    static final String TAG = "demo";

    static final int ES = 0;
    static final int AP = 1;

    /* AP_SSID must match device's ssid. You can configure it with target lib. */
    static final String DEVICE_SSID = "es";

    int mMode = ES;
    int mLocalIp;
    String mSsid = null;
    String mPassword = null;
    Thread mThread = null;
    boolean mDone = true;
    boolean mWifiConnected = false;
    TextView mInfo = null;
    ListView mListView = null;
    ArrayAdapter<String> mListAdapter = null;

    IntentFilter mFilter = null;
    BroadcastReceiver mReceiver = null;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main4);

        mInfo = (TextView) findViewById(R.id.switch_mode_prompt);
        mListView = (ListView) findViewById(R.id.ssid_list);
        mListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        mListView.setAdapter(mListAdapter);
        mListView.setOnItemClickListener(this);

        /* Set packet interval. Default 8ms in lib. Probably you don't need to set it */
        SharedPreferences sp = Settings.getPrefs(Demo4.this);
        String packetInterval = sp.getString("packet_interval", getString(R.string.default_packet_interval));
        int interval = Integer.parseInt(packetInterval);
        Neeze.SetPacketInterval(interval); /* default 8ms */
    }

    @Override
    public void onResume() {
        super.onResume();

        String ssid = getSsid();
        /*
        if (ssid == null) {
            Log.d(TAG, getString(R.string.connect_wifi));

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.connect_wifi);
            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    finish();
                }
            });
            builder.show();

            return;
        }*/

        if (ssid != null) {
            update();
            mLocalIp = getLocalIp();
        } else {
            mWifiConnected = false;
        }

        if (mFilter == null) {
            mFilter = new IntentFilter();
            mFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
            mReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    handleWifiEvent(context, intent);
                }
            };
        }

        registerReceiver(mReceiver, mFilter);
    }

    void update() {
        String ssid = getSsid();
        if (ssid != null) {
            if (ssid.equals(DEVICE_SSID)) {
                mMode = AP;
            } else {
                mMode = ES;
            }
        }

        LinearLayout ll = null;
        if (!mDone) {
            ll = (LinearLayout) findViewById(R.id.sending);
            ll.setVisibility(View.VISIBLE);
            if (mMode == ES) {
                mInfo.setText(R.string.switch_mode_prompt_in_es);
            } else {
                mInfo.setText(R.string.switch_mode_prompt_in_ap);
            }

            ll = (LinearLayout) findViewById(R.id.fill_ssid);
            ll.setVisibility(View.GONE);
        } else {
            ll = (LinearLayout) findViewById(R.id.sending);
            ll.setVisibility(View.GONE);
            ll = (LinearLayout) findViewById(R.id.fill_ssid);
            ll.setVisibility(View.VISIBLE);

            ll = (LinearLayout) findViewById(R.id.ssid_list_panel);
            if (ssid != null) {
                if (ssid.equals(DEVICE_SSID)) {
                    ll.setVisibility(View.VISIBLE);
                    TextView tv = (TextView) findViewById(R.id.ssid_list_header);
                    tv.setText(R.string.listen_for_ssid);
                    new ListenForSsidListTask().execute();
                } else {
                    EditText et = (EditText) findViewById(R.id.ssid);
                    et.setText(ssid);
                    ll.setVisibility(View.GONE);
                }
            } else {
                ll.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        unregisterReceiver(mReceiver);
    }

    public void onItemClick(AdapterView<?> apdater, View view, int pos, long id) {
        EditText et = (EditText) findViewById(R.id.ssid);
        et.setText(mListAdapter.getItem(pos));
    }

    void handleWifiEvent(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, action);
        if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
            ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            boolean connected = networkInfo.isConnected();
            if (mWifiConnected != connected) {
                mWifiConnected = connected;
                Log.d(TAG, "wifi network info, connected="+mWifiConnected);
                update();
            }
        }
    }

    class ListenForSsidListTask extends AsyncTask<Void, Void, Boolean> {
        byte[] list = null;
        protected void onPreExecute() {
            mListAdapter.clear();
        }

        protected Boolean doInBackground(Void... args) {
            list = Neeze.listenForSsidList();
            Log.d(TAG, "ssid list = "+list.length);
            return true;
        }

        protected void onPostExecute(Boolean success) {
            if (list == null || list.length == 0) {
                return;
            }

            int i = 0;
            byte len = 0;
            byte rssi = 0;
            byte sec = 0;
            while (i+2 < list.length) {
                /* 
                 * A sequence of rssi-sec-len-ssid
                 * octet[0]: rssi
                 * octet[1]: secutiry (0=none, 1=wep, 2=wpa/wpa2-psk, 3=wpa2-enterprise)
                 * octet[2]: ssid length
                 * octet[3...]: ssid bytes
                 */
                if (len == 0) {
                    rssi = list[i+0];
                    sec = list[i+1];
                    len = list[i+2];
                    i += 3;
                } else {
                    if (i+len > list.length) break;
                    String ssid = new String(list, i, len);
                    Log.d(TAG, String.format("%d/%d/%s", rssi, sec, ssid));
                    mListAdapter.add(ssid);
                    i += len;
                    len = 0;
                }
            }

            TextView tv = (TextView) findViewById(R.id.ssid_list_header);
            tv.setText(R.string.listen_done);
        }
    }

    public void onStartSending(View v) {
        if (!mWifiConnected) {
            Toast.makeText(this, R.string.connect_wifi, Toast.LENGTH_SHORT).show();
            return;
        }

        EditText et = (EditText) findViewById(R.id.ssid);
        mSsid = et.getText().toString();
        et = (EditText) findViewById(R.id.password);
        mPassword = et.getText().toString();

        mDone = false;
        update();

        if (mThread == null) {
            mThread = new Thread() {
                public void run() {
                    while (!mDone && mWifiConnected) {
                        if (mMode == ES) {
                            //Neeze.send(mSsid, mPassword, mLocalIp, 1729, "0123456789abcdef");
                            Neeze.send(mSsid, mPassword, mLocalIp, 1729);
                            //Neeze.send(mSsid, mPassword);
                        } else {
                            Neeze.sendToAp(mSsid, mPassword, mLocalIp, 1729, "");
                            //Neeze.sendToAp(mSsid, mPassword, 0, 0, "");
                        }
                    }
                }
            };
        }

        mThread.start();
    }

    public void onStopSending(View v) {
        mDone = true;
        mThread = null;
        update();
    }

    String getSsid() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        Log.d(TAG, "getSsid, wifi connected="+networkInfo.isConnected());
        if (networkInfo.isConnected()) {
            WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifiManager.getConnectionInfo();
            String ssid = info.getSSID();
            Log.d(TAG, "getSsid, ssid="+ssid);
            if (ssid.startsWith("\"")) {
                ssid = ssid.substring(1, ssid.length()-1);
            }

            return ssid;
        }

        return null;
    }

    int getLocalIp() {
        WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        mLocalIp = info.getIpAddress();
        return mLocalIp;
    }

    void updateWifiInfo() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        Log.d(TAG, "connected: "+networkInfo.isConnected());
        if (!networkInfo.isConnected()) {
            Log.d(TAG, getString(R.string.connect_wifi));

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.connect_wifi);
            builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    finish();
                }
            });
            builder.show();

            return;
        }
        
        WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        mLocalIp = info.getIpAddress();
        Log.d(TAG, String.format("ip: 0x%x", mLocalIp));

        EditText et = (EditText) findViewById(R.id.ssid);
        String ssid = info.getSSID();
        if (ssid.startsWith("\"")) {
            ssid = ssid.substring(1, ssid.length()-1);
        }

        if (!ssid.equals(DEVICE_SSID)) {
            et.setText(ssid);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
        case R.id.settings:
            Intent intent = new Intent();
            intent.setClass(this, Settings.class);
            startActivity(intent);
            return true;
        }

        return true;
    }
}
